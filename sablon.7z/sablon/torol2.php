<?php
$sorszam=$_POST["gomb"];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reggelizo";
echo '<head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />



</head>';
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$igaz=0;
/*echo '<form method="POST" action="torol2.php">'.'
<input type="text" id="emailcim1"><br>
<input type="text" id="telszam1"><br>';
echo '<button class="btn btn-danger btn-outline-warning" type="submit" name="gomb1" id="gomb1">'."Engedélyezés</button>";
echo '</form>';*/





$sql = "DELETE FROM asztalfoglalas WHERE sorszam=$sorszam;
";
if (mysqli_query($conn, $sql))
{
  echo "Foglalás sikeresen törölve";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>