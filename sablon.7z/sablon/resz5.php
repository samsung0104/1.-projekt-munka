  <section class="book_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Asztal foglalás
        </h2>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form_container">
            <form action="foglal.php" method="POST">
              <div>
                <input name="nev" id="nev" type="text" class="form-control" placeholder="Neved" />
              </div>
              <div>
                <input name="szam" id="szam" type="text" class="form-control" placeholder="Telefon számod" />
              </div>
              <div>
                <input name="email" id="email" type="email" class="form-control" placeholder="Email cimed" />
              </div>
              <div>
                <select name="fo" id="fo" class="form-control nice-select wide">
                  <option value="0" disabled selected>
                    Mennyi személy van?
                  </option>
                  <option value="2">
                    2
                  </option>
                  <option value="3">
                    3
                  </option>
                  <option value="4">
                    4
                  </option>
                  <option value="5">
                    5
                  </option>
                </select>
              </div>
              <div>
                <input name="datum" id="datum" type="date" class="form-control">
              </div>
              <div class="btn_box">
                <button>
                  Foglalás!
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-6">
          <div class="map_container ">
            <div id=""><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2672.130268246265!2d22.315262815880164!3d47.95320497196279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47387b605a2df797%3A0xecfdd80de87e2435!2zTcOhdMOpc3phbGthaSBTemFra8OpcHrDqXNpIENlbnRydW0gR8OpcMOpc3pldGkgVGVjaG5pa3VtIMOpcyBLb2xsw6lnaXVt!5e0!3m2!1shu!2shu!4v1635841136249!5m2!1shu!2shu" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end book section -->