<?php
$nev=$_POST["nev"];
$teloszam=$_POST["szam"];
$email=$_POST["email"];
$fo=$_POST["fo"];
$datum=$_POST["datum"];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reggelizo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO asztalfoglalas (nev,telszem,email,fo,datum)
VALUES ('$nev', '$teloszam', '$email', '$fo', '$datum')";
if (mysqli_query($conn, $sql))
{
  echo "Asztal foglalás leadása";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


mysqli_close($conn);
?>